<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Liveobs extends CI_Controller {
	var $Page_title = "Home";
	var $Page_name  = "home";
	var $Page_view  = "home";
	var $Page_menu  = "home";
	var $page_controllers = "home";
	var $Page_tbl   = "";
	public function index()
	{
		
	}
	
	public function local_start()
	{
		system("local_start.bat");
	}
	
	public function local_stop()
	{
		system("local_stop.bat");
	}
	
	public function youtube_start()
	{
		system("youtube_start.bat");
	}
	
	public function youtube_stop()
	{
		system("youtube_stop.bat");
	}
	
	public function restart_pc()
	{
		system("restart_pc.bat");
	}
}